import os

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()


def handle_request(prompt):
    """ handle API request for AI """

    client = OpenAI(api_key=os.getenv('API_KEY'))

    chat_completion = client.chat.completions.create(
        messages=[{'role': 'user', 'content': prompt}],
        model=os.getenv('AI_MODEL'),
    )

    response = chat_completion.choices[0].message.content
    return response


if __name__ == '__main__':
    my_prompt = "What is the capital of France?"
    my_response = handle_request(my_prompt)
    print(my_response)
