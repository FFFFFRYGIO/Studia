from ProblemsBase import ProblemsBase


class TimeProblem(ProblemsBase):
    """ TimeProblem class for time-related problems to be solved by different prompt engineering techniques """

    def __init__(self):
        super(TimeProblem, self).__init__("time_problems.json")

    def least_to_most_technique(self):
        """ Least-to-most technique for TimeProblem """

        learning_prompt = """
Jeśli dziś jest środa, to który dzień tygodnia będzie za 100 dni?

Rozkładamy problem na małe problemy:
    Pytanie: Ile dni jest w tygodniu?
    Odpowiedź: 7 dni
    Pytanie: Ile pełnych tygodni mieści się w 100 dniach?
    Odpowiedź: 14 tygodni (ponieważ 100 podzielone przez 7 to 14 z resztą 2)
    Pytanie: Jaki jest dzień tygodnia po 100 dniach, jeśli reszta z dzielenia to 2?
    Odpowiedź: Piątek (ponieważ dwa dni po środzie to piątek)

Poprawna odpowiedź to: Piątek

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def self_asking_technique(self):
        """ Self-asking technique for TimeProblem """

        learning_prompt = """
Jeśli dziś jest środa, to który dzień tygodnia będzie za 100 dni?

Rozważmy to krok po kroku:
    Pytanie: Ile dni jest w tygodniu?
    Odpowiedź: 7 dni
    Pytanie: Jak obliczyć dzień tygodnia po 100 dniach?
    Odpowiedź: Podzielić 100 przez 7, co daje 14 tygodni i resztę 2 dni
    Pytanie: Jeśli dziś jest środa, jaki dzień będzie za 2 dni?
    Odpowiedź: Piątek

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def meta_technique(self):
        """ Meta technique for TimeProblem """

        learning_prompt = """
Jeśli dziś jest środa, to który dzień tygodnia będzie za 100 dni?

Aby odpowiedzieć na to pytanie, musimy najpierw zrozumieć kolejność:
    1. Tydzień ma 7 dni
    2. 100 dni podzielone przez 7 dni to 14 tygodni z resztą 2 dni

Teraz możemy ustalić, że:
    2 dni po środzie to piątek

Więc odpowiedź to piątek.

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def chain_of_thought_technique(self):
        """ Chain-of-thought technique for TimeProblem """

        learning_prompt = """
Jeśli dziś jest środa, to który dzień tygodnia będzie za 100 dni?

Zacznijmy od porządku:
    - Tydzień ma 7 dni
    - 100 dni to 14 tygodni z resztą 2 dni
    - Jeśli dziś jest środa, to za 2 dni będzie piątek

Więc odpowiedź to piątek.

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def re_act_technique(self):
        """ ReAct technique for TimeProblem """

        learning_prompt = """
Jeśli dziś jest środa, to który dzień tygodnia będzie za 100 dni?

Analizuję fakty:
    - Tydzień ma 7 dni
    - 100 dni to 14 tygodni z resztą 2 dni

Na podstawie tych informacji, ustalam porządek:
    - Jeśli dziś jest środa, to za 2 dni będzie piątek

Więc odpowiedź to piątek.

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)


if __name__ == "__main__":
    time_problem = TimeProblem()
    # time_problem.least_to_most_technique()
    # time_problem.self_asking_technique()
    # time_problem.meta_technique()
    # time_problem.chain_of_thought_technique()
    # time_problem.re_act_technique()
