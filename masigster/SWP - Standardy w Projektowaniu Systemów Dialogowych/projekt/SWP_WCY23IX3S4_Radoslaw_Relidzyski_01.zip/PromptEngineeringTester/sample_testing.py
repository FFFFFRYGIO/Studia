import json
import os

from handle_request import handle_request


problems_file = os.path.join("problem_source", "various_problems.json")
with open(problems_file, encoding='utf-8') as file:
    problems = json.load(file)


if __name__ == '__main__':
    for problem in problems:
        print(f"Problem: {problem['problem']}")
        response = handle_request(problem.get("problem"))
        print(f"Response: {response}")
        print(f"Solution: {problem.get("solution")}")
        print()
