import json
import os
from abc import ABC, abstractmethod

from handle_request import handle_request


class ProblemsBase(ABC):
    """ Base class for problems to be solved by different prompt engineering techniques """

    def __init__(self, json_file):
        self.problems_file = os.path.join("problem_source", json_file)
        with open(self.problems_file, encoding='utf-8') as file:
            self.problems = json.load(file)

    def run_technique(self, learning_prompt):
        """ run all problems for technique """

        for problem in self.problems:
            formatted_prompt = learning_prompt % problem.get("problem")
            print(f"Problem: {problem['problem']}")
            response = handle_request(formatted_prompt)
            print(f"Response: {response}")
            print(f"Solution: {problem.get("solution")}")
            print()

    @abstractmethod
    def least_to_most_technique(self):
        """
        Least-to-most technique:
        This method involves starting with the simplest or easiest problems and progressively moving to more complex ones.
        It helps build confidence and understanding incrementally.
        """
        pass

    @abstractmethod
    def self_asking_technique(self):
        """
        Self-asking technique:
        This method encourages learners to ask themselves questions about the material they are studying.
        It helps deepen understanding and promotes active engagement with the content.
        """
        pass

    @abstractmethod
    def meta_technique(self):
        """
        Meta technique:
        This method involves thinking about one's own thinking processes.
        It includes strategies like planning, monitoring, and evaluating one's understanding and learning strategies.
        """
        pass

    @abstractmethod
    def chain_of_thought_technique(self):
        """
        Chain-of-thought technique:
        This method involves linking ideas together in a logical sequence to solve problems or understand concepts.
        It encourages coherent and structured thinking.
        """
        pass

    @abstractmethod
    def re_act_technique(self):
        """
        ReAct technique:
        This method combines reflection and action, encouraging learners to reflect on their actions and adjust their strategies accordingly.
        It fosters continuous improvement and adaptive learning.
        """
        pass
