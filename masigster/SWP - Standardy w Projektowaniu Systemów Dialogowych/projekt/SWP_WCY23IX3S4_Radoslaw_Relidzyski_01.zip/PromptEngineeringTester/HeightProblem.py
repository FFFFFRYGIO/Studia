from ProblemsBase import ProblemsBase


class HeightProblem(ProblemsBase):
    """ HeightProblem class for height problems to be solved by different prompt engineering techniques """

    def __init__(self):
        super(HeightProblem, self).__init__("height_problems.json")

    def least_to_most_technique(self):
        """ Least-to-most technique for HeightProblem """

        learning_prompt = """
Jacek jest wyższy od Tomka, ale niższy od Adama. Adam jest niższy od Bartka. Kto jest najniższy?

Rozkładamy poblem na małe problemy:
    Pytanie: Kto jest wyższy, Jacek czy Tomek?
    Odpowiedź: Jacek
    Pytanie: Kto jest wyższy, Adam czy Jacek?
    Odpowiedź: Adam
    Pytanie: Kto jest wyższy, Adam czy Bartek?
    Odpowiedź: Bartek
    Pytanie: Kto jest najniższy spośród Jacka, Tomka, Adama i Bartka?
    Odpowiedź: Tomek
Poprawna odpowiedź to: Tomek

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def self_asking_technique(self):
        """ Self-asking technique for HeightProblem """

        learning_prompt = """
Jacek jest wyższy od Tomka, ale niższy od Adama. Adam jest niższy od Bartka. Kto jest najniższy?

Rozważmy to krok po kroku:
    Pytanie: Co wiem o Jacku i Tomku?
    Odpowiedź: Jacek jest wyższy od Tomka
    Pytanie: Co wiem o Adamie i Jacku?
    Odpowiedź: Adam jest wyższy od Jacka
    Pytanie: Co wiem o Adamie i Bartku?
    Odpowiedź: Bartek jest wyższy od Adama
    Pytanie: Kto jest najniższy?
    Odpowiedź: Tomek

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def meta_technique(self):
        """ Meta technique for HeightProblem """

        learning_prompt = """
Jacek jest wyższy od Tomka, ale niższy od Adama. Adam jest niższy od Bartka. Kto jest najniższy?

Aby odpowiedzieć na to pytanie, musimy najpierw zrozumieć kolejność:
    1. Jacek > Tomek
    2. Adam > Jacek
    3. Bartek > Adam

Teraz możemy ustalić, że:
    Bartek > Adam > Jacek > Tomek

Więc najniższy jest Tomek.

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def chain_of_thought_technique(self):
        """ Chain-of-thought technique for HeightProblem """

        learning_prompt = """
Jacek jest wyższy od Tomka, ale niższy od Adama. Adam jest niższy od Bartka. Kto jest najniższy?

Zacznijmy od porządku:
    - Jacek jest wyższy od Tomka, więc Jacek > Tomek
    - Adam jest wyższy od Jacka, więc Adam > Jacek > Tomek
    - Bartek jest wyższy od Adama, więc Bartek > Adam > Jacek > Tomek

Więc najniższy jest Tomek.

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def re_act_technique(self):
        """ ReAct technique for HeightProblem """

        learning_prompt = """
Jacek jest wyższy od Tomka, ale niższy od Adama. Adam jest niższy od Bartka. Kto jest najniższy?

Analizuję fakty:
    - Jacek > Tomek
    - Adam > Jacek
    - Bartek > Adam

Na podstawie tych informacji, ustalam porządek:
    Bartek > Adam > Jacek > Tomek

Więc najniższy jest Tomek.

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)


if __name__ == "__main__":
    height_problem = HeightProblem()
    # height_problem.least_to_most_technique()
    # height_problem.self_asking_technique()
    # height_problem.meta_technique()
    # height_problem.chain_of_thought_technique()
    # height_problem.re_act_technique()
