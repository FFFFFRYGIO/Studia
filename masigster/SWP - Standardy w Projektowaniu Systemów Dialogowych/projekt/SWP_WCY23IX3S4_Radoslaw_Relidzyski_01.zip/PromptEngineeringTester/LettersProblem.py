from ProblemsBase import ProblemsBase


class LettersProblem(ProblemsBase):
    """ LettersProblem class for letter-related problems to be solved by different prompt engineering techniques """

    def __init__(self):
        super(LettersProblem, self).__init__("letters_problems.json")

    def least_to_most_technique(self):
        """ Least-to-most technique for LettersProblem """

        learning_prompt = """
Ułóż litery „EALNG” w kolejności alfabetycznej.

Rozkładamy problem na małe problemy:
    Pytanie: Jakie litery mamy?
    Odpowiedź: E, A, L, N, G
    Pytanie: Jaka jest pierwsza litera w kolejności alfabetycznej?
    Odpowiedź: A
    Pytanie: Jaka jest kolejna litera po A?
    Odpowiedź: E
    Pytanie: Jaka jest kolejna litera po E?
    Odpowiedź: G
    Pytanie: Jaka jest kolejna litera po G?
    Odpowiedź: L
    Pytanie: Jaka jest kolejna litera po L?
    Odpowiedź: N

Poprawna odpowiedź to: A, E, G, L, N

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def self_asking_technique(self):
        """ Self-asking technique for LettersProblem """

        learning_prompt = """
Ułóż litery „EALNG” w kolejności alfabetycznej.

Rozważmy to krok po kroku:
    Pytanie: Jakie litery mamy?
    Odpowiedź: E, A, L, N, G
    Pytanie: Jak obliczyć kolejność alfabetyczną liter?
    Odpowiedź: Porównaj każdą literę, zaczynając od A
    Pytanie: Jakie litery mamy po A?
    Odpowiedź: E
    Pytanie: Jakie litery mamy po E?
    Odpowiedź: G
    Pytanie: Jakie litery mamy po G?
    Odpowiedź: L
    Pytanie: Jakie litery mamy po L?
    Odpowiedź: N

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def meta_technique(self):
        """ Meta technique for LettersProblem """

        learning_prompt = """
Ułóż litery „EALNG” w kolejności alfabetycznej.

Aby odpowiedzieć na to pytanie, musimy najpierw zrozumieć kolejność alfabetyczną:
    1. Rozpoznajemy litery: E, A, L, N, G
    2. Porządkujemy je alfabetycznie: A, E, G, L, N

Poprawna odpowiedź to: A, E, G, L, N

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def chain_of_thought_technique(self):
        """ Chain-of-thought technique for LettersProblem """

        learning_prompt = """
Ułóż litery „EALNG” w kolejności alfabetycznej.

Zacznijmy od porządku:
    - Mamy litery: E, A, L, N, G
    - W kolejności alfabetycznej są: A, E, G, L, N

Więc odpowiedź to: A, E, G, L, N

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)

    def re_act_technique(self):
        """ ReAct technique for LettersProblem """

        learning_prompt = """
Ułóż litery „EALNG” w kolejności alfabetycznej.

Analizuję fakty:
    - Mamy litery: E, A, L, N, G
    - Uporządkujmy je alfabetycznie: A, E, G, L, N

Na podstawie tych informacji ustalamy, że poprawna kolejność to: A, E, G, L, N

Wykorzystaj to podejście do rozwiązania tego problemu:
%s
        """

        self.run_technique(learning_prompt)


if __name__ == "__main__":
    letters_problem = LettersProblem()
    # letters_problem.least_to_most_technique()
    # letters_problem.self_asking_technique()
    # letters_problem.meta_technique()
    # letters_problem.chain_of_thought_technique()
    # letters_problem.re_act_technique()
